//: velocimetro

import UIKit

enum Velocidades : Int {
    case apagado = 0, velocidadBaja = 20, velocidadMedia = 50, velocidadAlta = 120
    
    init(velocidadInicial : Velocidades){
        self = velocidadInicial
    }
}

class Auto{
    var velocidad: Velocidades
    
    init() {
        self.velocidad = Velocidades(velocidadInicial: .apagado)
    }

    func cambioDeVelocidad() -> (actual : Int, velocidadEnCadena : String){
        switch velocidad{
        case Velocidades.apagado :
            velocidad = Velocidades.velocidadBaja
            return (Velocidades.apagado.rawValue, "Apagado")
        case Velocidades.velocidadBaja :
            velocidad = Velocidades.velocidadMedia
            return (Velocidades.velocidadBaja.rawValue, "Velocidad Baja")
        case Velocidades.velocidadMedia :
            velocidad = Velocidades.velocidadAlta
            return (Velocidades.velocidadMedia.rawValue, "Velocidad Media")
        case Velocidades.velocidadAlta:
            velocidad = Velocidades.velocidadMedia
            return (Velocidades.velocidadAlta.rawValue, "Velocidad Alta")
        }
    }
}

var auto = Auto()
for i in 0...19{
    var tupla = auto.cambioDeVelocidad()
    print("\(tupla.0),\(tupla.1)")
}


